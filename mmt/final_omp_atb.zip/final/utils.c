#include "utils.h"

int min( int a, int b ) {
    if (a > b)
        return b;
    else 
        return a;
}