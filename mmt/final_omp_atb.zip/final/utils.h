#ifndef utilsval
#define utilsval 10

int min( int a, int b );

#endif