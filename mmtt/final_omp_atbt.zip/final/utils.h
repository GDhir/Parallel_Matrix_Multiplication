#ifndef utilsval
#define utilsval 20

int min( int a, int b );

#endif